import { db, games, bets } from '../index';
import { eq, and } from 'drizzle-orm';
import { computeCrashPoint, deriveNextHash, crashPointToElapsed } from './rng.service';
import { creditWallet, debitWallet } from './wallet.service';

export type GamePhase = 'waiting' | 'betting' | 'flying' | 'crashed';

export interface GameState {
  id: number;
  hash: string;
  state: GamePhase;
  crashPoint: number | null;   // x100, null until crashed
  elapsedMs: number;           // ms since flying started, 0 when not flying
  playerCount: number;
  totalBetsCents: number;
}

export interface ActiveBet {
  userId: number;
  username: string;
  amountCents: number;
  autoCashoutAt: number | null;
  cashedOutAt: number | null;
}

// In-memory game state — synced to DB at key transitions
let currentGame: GameState | null = null;
let activeBets: Map<number, ActiveBet> = new Map(); // userId → bet
let flyingStartTime: number | null = null;
let tickInterval: ReturnType<typeof setInterval> | null = null;
let crashTimeout: ReturnType<typeof setTimeout> | null = null;
let hashChain: string[] = [];
let chainIndex = 0;

// Event callbacks — set by the WS server
type EventHandler = (event: string, data: unknown) => void;
let broadcast: EventHandler = () => {};

export function setBroadcast(fn: EventHandler) {
  broadcast = fn;
}

export function getCurrentGame(): GameState | null {
  return currentGame;
}

export function getActiveBets(): ActiveBet[] {
  return Array.from(activeBets.values());
}

/**
 * Initialize the game engine with a hash chain.
 * Call this once at server startup.
 */
export async function initGameEngine(chain: string[]): Promise<void> {
  hashChain = chain;
  chainIndex = 0;

  // Check for any in-progress game in DB and recover
  const [lastGame] = await db
    .select()
    .from(games)
    .orderBy(games.id)
    .limit(1);

  if (lastGame && (lastGame.state === 'flying' || lastGame.state === 'betting')) {
    // Recover — mark as crashed with refunds
    await recoverInterruptedGame(lastGame.id);
  }

  startNewRound();
}

/**
 * Start a new round: waiting → betting → flying → crashed
 */
async function startNewRound(): Promise<void> {
  activeBets.clear();
  flyingStartTime = null;

  const hash = hashChain[chainIndex % hashChain.length];
  chainIndex++;

  // Insert game record
  const [game] = await db
    .insert(games)
    .values({
      hash,
      state: 'waiting',
      bettingOpenAt: new Date(Date.now() + 2000), // 2s wait then betting opens
    })
    .returning();

  currentGame = {
    id:             game.id,
    hash:           game.hash,
    state:          'waiting',
    crashPoint:     null,
    elapsedMs:      0,
    playerCount:    0,
    totalBetsCents: 0,
  };

  broadcast('1501', { id: game.id, wait_ms: 2000 });

  // Betting phase after 2s
  setTimeout(() => openBetting(game.id, hash), 2000);
}

async function openBetting(gameId: number, hash: string): Promise<void> {
  if (!currentGame || currentGame.id !== gameId) return;

  currentGame.state = 'betting';
  await db.update(games).set({ state: 'betting', bettingOpenAt: new Date() }).where(eq(games.id, gameId));

  broadcast('betting_open', { gameId });

  // Betting phase lasts 5 seconds
  setTimeout(() => closeBetting(gameId, hash), 5000);
}

async function closeBetting(gameId: number, hash: string): Promise<void> {
  if (!currentGame || currentGame.id !== gameId) return;

  currentGame.state = 'flying';
  const crashX100   = computeCrashPoint(hash);
  const flightMs    = crashPointToElapsed(crashX100);
  flyingStartTime   = Date.now();

  await db.update(games).set({
    state:          'flying',
    bettingCloseAt: new Date(),
    flyingStartAt:  new Date(),
  }).where(eq(games.id, gameId));

  broadcast('1502', {}); // Betting closed

  // Tick every 150ms — broadcast elapsed time
  let elapsed = 0;
  tickInterval = setInterval(() => {
    elapsed += 150;
    currentGame!.elapsedMs = elapsed;

    // Check auto cashouts
    for (const [userId, bet] of activeBets.entries()) {
      if (bet.cashedOutAt === null && bet.autoCashoutAt !== null) {
        const currentMultX100 = Math.round(Math.exp(elapsed / 35000) * 100);
        if (currentMultX100 >= bet.autoCashoutAt) {
          processCashout(userId, gameId, bet.autoCashoutAt);
        }
      }
    }

    broadcast('1503', elapsed);
  }, 150);

  // Crash at predetermined time
  crashTimeout = setTimeout(() => crashGame(gameId, crashX100, flightMs), flightMs);
}

async function crashGame(gameId: number, crashX100: number, elapsedMs: number): Promise<void> {
  if (!currentGame || currentGame.id !== gameId) return;

  // Clear tick interval
  if (tickInterval) { clearInterval(tickInterval); tickInterval = null; }

  currentGame.state      = 'crashed';
  currentGame.crashPoint = crashX100;

  const crashedAt = new Date();

  await db.update(games).set({
    state:      'crashed',
    crashPoint: crashX100,
    crashedAt,
    elapsedMs,
  }).where(eq(games.id, gameId));

  // Mark all remaining active bets as lost
  for (const [userId, bet] of activeBets.entries()) {
    if (bet.cashedOutAt === null) {
      await db.update(bets)
        .set({ state: 'lost' })
        .where(and(eq(bets.gameId, gameId), eq(bets.userId, userId)));
    }
  }

  broadcast('1504', {
    forced:   false,
    elapsed:  elapsedMs,
    gameId,
    gameCrash: crashX100 / 100,
    gameHash:  currentGame.hash,
  });

  // Start next round after 3s
  setTimeout(() => startNewRound(), 3000);
}

/**
 * Place a bet — called from the API route.
 * Returns error string or null on success.
 */
export async function placeBet(
  userId: number,
  username: string,
  amountCents: number,
  autoCashoutAt: number | null
): Promise<{ success: boolean; error?: string; betId?: number }> {
  if (!currentGame || currentGame.state !== 'betting') {
    return { success: false, error: 'Betting is not open' };
  }
  if (activeBets.has(userId)) {
    return { success: false, error: 'You already have an active bet' };
  }
  if (amountCents < 100) { // Min KES 1
    return { success: false, error: 'Minimum bet is KES 1' };
  }
  if (amountCents > 300000) { // Max KES 3000
    return { success: false, error: 'Maximum bet is KES 3,000' };
  }

  // Debit wallet
  const debit = await debitWallet(userId, amountCents, 'bet', {
    gameId:      currentGame.id,
    description: `Bet on game #${currentGame.id}`,
  });

  if (!debit.success) {
    return { success: false, error: debit.error };
  }

  // Insert bet record
  const [bet] = await db
    .insert(bets)
    .values({
      gameId:       currentGame.id,
      userId,
      amountCents,
      state:        'active',
      autoCashoutAt,
      xid:          activeBets.size,
    })
    .returning({ id: bets.id });

  activeBets.set(userId, { userId, username, amountCents, autoCashoutAt, cashedOutAt: null });

  currentGame.playerCount++;
  currentGame.totalBetsCents += amountCents;

  broadcast('1507', {
    plays: [{
      user_id:    userId,
      username,
      bet:        amountCents / 100,
      game_id:    currentGame.id,
      currency:   'KES',
      idx:        activeBets.size - 1,
      created_at: new Date().toISOString(),
    }]
  });

  return { success: true, betId: bet.id };
}

/**
 * Process a cashout — called from API route or auto cashout trigger.
 * CRITICAL: validated against server crash timestamp.
 */
export async function processCashout(
  userId: number,
  gameId: number,
  requestedMultX100?: number
): Promise<{ success: boolean; payoutCents?: number; error?: string }> {
  if (!currentGame || currentGame.id !== gameId) {
    return { success: false, error: 'Game not found' };
  }

  // CRITICAL CHECK: reject if game has already crashed
  if (currentGame.state === 'crashed') {
    return { success: false, error: 'Game has already crashed' };
  }

  if (currentGame.state !== 'flying') {
    return { success: false, error: 'Game is not in flight' };
  }

  const bet = activeBets.get(userId);
  if (!bet) {
    return { success: false, error: 'No active bet found' };
  }
  if (bet.cashedOutAt !== null) {
    return { success: false, error: 'Already cashed out' };
  }

  // Current multiplier x100
  const elapsed = Date.now() - (flyingStartTime ?? 0);
  const currentMultX100 = Math.round(Math.exp(elapsed / 35000) * 100);

  // Mark as cashed out in memory IMMEDIATELY before any async ops
  bet.cashedOutAt = currentMultX100;

  const payoutCents = Math.floor(bet.amountCents * currentMultX100 / 100);

  // Update bet in DB
  await db.update(bets).set({
    state:         'cashed_out',
    cashedOutAt:   currentMultX100,
    cashedOutTime: new Date(),
    payoutCents,
  }).where(and(eq(bets.gameId, gameId), eq(bets.userId, userId)));

  // Credit wallet
  await creditWallet(userId, payoutCents, 'win', {
    gameId,
    description: `Cashout at ${(currentMultX100 / 100).toFixed(2)}x on game #${gameId}`,
  });

  broadcast('1505', {
    '0': {
      count:  1,
      amount: { KES: payoutCents / 100 },
    },
    [userId]: { '0': currentMultX100 / 100 },
  });

  return { success: true, payoutCents };
}

async function recoverInterruptedGame(gameId: number): Promise<void> {
  // Refund all bets for interrupted game
  const gameBets = await db.select().from(bets).where(eq(bets.gameId, gameId));
  for (const bet of gameBets) {
    if (bet.state === 'active') {
      await creditWallet(bet.userId, Number(bet.amountCents), 'refund', {
        gameId,
        description: `Refund for interrupted game #${gameId}`,
      });
      await db.update(bets).set({ state: 'refunded' }).where(eq(bets.id, bet.id));
    }
  }
  await db.update(games).set({ state: 'crashed', forced: true }).where(eq(games.id, gameId));
}
